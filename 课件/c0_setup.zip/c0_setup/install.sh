wget https://c0.cs.cmu.edu/downloads/cc0-debian.deb
sudo apt install ./cc0-debian.deb
cc0 -h
