mkdir c0_mac && tar -xvzf c0_mac.tar.gz --directory=./c0_mac
cd c0_mac
bin/cc0 -d doc/src/exp.c0 doc/src/exp-test.c0 && ./a.out
bin/coin -l conio doc/src/exp.c0
